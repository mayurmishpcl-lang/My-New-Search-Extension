document.getElementById('searchBtn').addEventListener('click', function() {
  let query = document.getElementById('searchInput').value.trim();
  if (query) {
    // Google search URL with the query
    let url = 'https://www.google.com/search?q=' + encodeURIComponent(query);
    
    // Naya tab kholna
    window.open(url, '_blank');
  } else {
    alert('Please enter a search term!');
  }
});
