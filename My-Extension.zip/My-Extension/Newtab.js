<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Custom New Tab</title>
  <link rel="stylesheet" href="styles.css" />
</head>
<body>
  <div class="container">
    <div class="animated-background">Search here</div>
    <form id="searchForm">
      <input type="text" id="searchInput" placeholder="Search Google or type a URL" autocomplete="off" />
      <button type="submit" id="searchBtn">Search</button>
    </form>
  </div>
  <!-- External script only -->
  <script src="newtab.js"></script>
</body>
</html>
s